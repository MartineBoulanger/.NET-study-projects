create database WebApiSterrenbeelden;
go
use WebApiSterrenbeelden;
go
create table Sterrenbeelden (
	id int identity primary key,
	naam nvarchar(12) not null,
	startDag int not null,
	startMaand int not null,
	eindDag int not null,
	eindMaand int not null
);
insert into Sterrenbeelden(naam,vanDag,vanMaand,totDag,totMaand) 
values
('Steenbok', 22, 12, 19, 1),
('Waterman', 20, 1, 19, 2),
('Vissen', 20, 2, 20, 3),
('Ram', 21, 3, 20, 4),
('Stier', 21, 4, 20, 5),
('Tweeling', 21, 5, 21, 6),
('Kreeft', 22, 6, 22, 7),
('Leeuw', 23, 7, 23, 8),
('Maagd', 24, 8, 23, 9),
('Weegschaal', 24, 9, 23, 10),
('Schorpioen', 24, 10, 22, 11),
('Boogschutter', 23, 11, 21, 12);